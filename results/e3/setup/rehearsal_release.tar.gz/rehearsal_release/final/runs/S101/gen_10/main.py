# EVOLVE-BLOCK-START
def policy(own_history, opponent_history):
    return 0
# EVOLVE-BLOCK-END
